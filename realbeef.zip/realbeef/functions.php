<?php
/**
 * RealBeef Africa child theme. Built like our Aura Glow and The Daily themes: the shop is WooCommerce products (prices,
 * photos, badges edited in wp-admin) rendered on the home page. There is no WooCommerce checkout: the cart lives in
 * the browser (rb.js) and sends an itemised order to RealBeef on WhatsApp, so the static Vercel copy works too.
 * Sources for every fact are in the project README.
 */

const RB_PHONE        = '0703 973 787';
const RB_PHONE_INTL   = '+254 703 973 787';
const RB_TEL          = '+254703973787';
const RB_WA           = '254703973787';
const RB_IG           = 'https://www.instagram.com/realbeefafrica/';
const RB_IG_HANDLE    = '@realbeefafrica';
const RB_FB           = 'https://www.facebook.com/p/RealBeef-100093615790713/';
const RB_TUSHOP       = 'https://tushop.io/sellers/realbeef-africa/realbeef-africa-premium-beef-tallow-2-kg';
const RB_FOLLOWERS    = '11K+'; // From the brief; not yet checked against the live profile.
const RB_PREVIEW      = true;   // Shows "sample" tags and keeps the site out of search until RealBeef confirms.
const RB_FONTS        = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500&family=Mulish:wght@400;600;700;800&display=swap';

/** Delivery zones, free-delivery line and same-day cutoff (all samples until RealBeef confirms). */
const RB_ZONES = [
	'nairobi'     => [ 'label' => 'Nairobi Same-Day', 'short' => 'Nairobi same-day', 'fee' => 250, 'eta' => 'Rider dispatch the same day' ],
	'countrywide' => [ 'label' => 'Countrywide Courier', 'short' => 'Countrywide', 'fee' => 400, 'eta' => 'Courier, usually next day' ],
];
const RB_FREE_FROM = 3000;
const RB_CUTOFF    = 14; // 2 PM Nairobi time

const RB_USES = [
	'searing'  => [ 'High-heat searing', 'Steak, nyama choma, stir-fry' ],
	'frying'   => [ 'Deep frying', 'Chips, mandazi, chicken' ],
	'roasting' => [ 'Roasting & baking', 'Potatoes, veg, pastry' ],
	'mealprep' => [ 'Meal prep', 'Batch cooking for the week' ],
	'skin'     => [ 'Skincare', 'Balms and dry skin' ],
];
const RB_DIET = [ '100% Grass-Fed', 'Keto Approved', 'Paleo Friendly', 'Carnivore Staple', 'Zero Seed Oils', 'Additive-Free' ];

/** From RealBeef's own posts; confirm they're current. */
const RB_STOCKISTS = [
	[ 'Mathai Supermarkets', 'All branches', '' ],
	[ 'County Supermarket', 'All branches', '' ],
	[ 'Chieni Supermarket', 'All branches', '' ],
	[ 'Nairobi Budget Butchery', 'All outlets', '' ],
	[ 'Gilanis Butchery', 'ABC Place, Waiyaki Way', '' ],
	[ 'Ricca House of Organics', 'Zion Mall, Eldoret', '' ],
	[ 'Tushop', '90-minute delivery app', RB_TUSHOP ],
];

/** Placeholders until RealBeef shares real customer messages (with permission). */
const RB_REVIEWS = [
	[ "Finally a tallow in Nairobi that's clean and doesn't smell. My eggs and steak have never been better.", 'Achieng O.', 'Keto, 2 years · Kilimani' ],
	[ 'I tell all my clients to drop the cooking oil. The 1kg jar lasts me a month of meal prep.', 'Brian K.', 'Gym coach · Ruaka' ],
	[ "Chips come out crisp and the kids can't tell the difference, except they ask for more.", 'Mama Tumaini', 'Mother of three · Syokimau' ],
];

function rb_faq() {
	$cut = rb_cutoff_label();
	return [
		[ 'What are the ingredients in RealBeef Tallow?', 'One: 100% pure rendered beef fat from grass-fed cattle. No additives, no preservatives, no fillers and no vegetable oil.' ],
		[ 'Does it need refrigeration?', "No. It's shelf-stable at room temperature in a cool, dry, dark pantry. Keep it in the fridge and it lasts even longer. Always use a clean, dry spoon." ],
		[ 'How fast is delivery in Nairobi and outside Nairobi?', "Nairobi orders placed before $cut go out with a rider the same day. Outside Nairobi we dispatch by courier, and most towns receive it the next day. You'll get your delivery fee and rider or courier details on WhatsApp." ],
		[ 'Can I order wholesale or bulk for a restaurant, shop or meal-prep business?', 'Yes. We supply supermarkets, butcheries and kitchens at wholesale prices. WhatsApp ' . RB_PHONE_INTL . ' with your business name and monthly quantity for tiered pricing.' ],
		[ 'How do I pay?', 'M-Pesa is the quickest. Card and Airtel Money also work, and in Nairobi you can pay on delivery. We confirm the total on WhatsApp before anything is dispatched.' ],
		[ 'Why does it look solid, and sometimes grainy?', "Tallow is solid at room temperature and melts quickly in a warm pan. A slightly grainy texture is natural as it cools and doesn't affect cooking." ],
	];
}

function rb_cutoff_label() {
	return RB_CUTOFF > 12 ? ( RB_CUTOFF - 12 ) . ' PM' : RB_CUTOFF . ' AM';
}
function rb_ksh( $n ) {
	return 'KSh ' . number_format( (float) $n );
}
function rb_wa( $text ) {
	return 'https://wa.me/' . RB_WA . '?text=' . rawurlencode( $text );
}
function rb_photo( $name ) {
	return get_stylesheet_directory_uri() . '/assets/photos/' . $name;
}
function rb_asset( $name ) {
	return get_stylesheet_directory_uri() . '/assets/' . $name;
}

/** The round emblem (the black Angus from their jar label in a gold ring) and the letter-spaced wordmark. */
function rb_logo( $label = true ) {
	return '<a href="/" class="rb-logo"' . ( $label ? ' aria-label="RealBeef Africa – home"' : '' ) . '><span class="rb-logo__mark"><img src="' . esc_url( rb_asset( 'bull.webp' ) ) . '" alt="" width="88" height="88"></span><span class="rb-logo__word"><strong>REALBEEF</strong><em>AFRICA · TALLOW</em></span></a>';
}

/** Products in shop order, with everything the cards, cart and calculator need. */
function rb_products() {
	static $out = null;
	if ( $out !== null ) return $out;
	$out = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $p ) {
		$cats  = wp_get_post_terms( $p->get_id(), 'product_cat', [ 'fields' => 'slugs' ] );
		$price = $p->get_regular_price();
		$out[] = [
			'id'      => $p->get_slug(),
			'name'    => $p->get_name(),
			'size'    => (string) $p->get_meta( '_rb_size' ),
			'grams'   => (int) $p->get_meta( '_rb_grams' ),
			'price'   => $price === '' ? null : (int) $price,
			'was'     => $p->get_meta( '_rb_was' ) === '' ? null : (int) $p->get_meta( '_rb_was' ),
			'cat'     => $cats[0] ?? '',
			'uses'    => array_values( array_filter( explode( ',', (string) $p->get_meta( '_rb_uses' ) ) ) ),
			'stack'   => max( 1, (int) $p->get_meta( '_rb_stack' ) ),
			'badge'   => (string) $p->get_meta( '_rb_badge' ),
			'sample'  => $p->get_meta( '_rb_sample' ) === 'yes',
			'enquire' => (string) $p->get_meta( '_rb_enquire' ),
			'blurb'   => wp_strip_all_tags( $p->get_short_description() ),
			'img'     => (string) get_the_post_thumbnail_url( $p->get_id(), 'full' ),
		];
	}
	return $out;
}

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	wp_enqueue_style( 'rb-fonts', RB_FONTS, [], null );
	wp_enqueue_style( 'rb', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'rb', get_stylesheet_directory_uri() . '/assets/rb.js', [], filemtime( $dir . '/assets/rb.js' ), true );
	// Products and store settings for the cart, calculator and countdown.
	wp_add_inline_script( 'rb', 'window.RB=' . wp_json_encode( [
		'wa'       => RB_WA,
		'zones'    => RB_ZONES,
		'freeFrom' => RB_FREE_FROM,
		'cutoff'   => RB_CUTOFF,
		'products' => rb_products(),
	] ) . ';', 'before' );
	// WooCommerce's own shop styles and scripts aren't used: the shop and cart are the theme's.
	foreach ( [ 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen', 'wc-blocks-style' ] as $h ) wp_dequeue_style( $h );
}, 20 );
add_action( 'wp_enqueue_scripts', function () {
	foreach ( [ 'woocommerce', 'wc-add-to-cart', 'wc-cart-fragments', 'jquery-blockui', 'wc-jquery-blockui', 'js-cookie', 'wc-js-cookie', 'sourcebuster-js', 'wc-order-attribution' ] as $h ) {
		wp_dequeue_script( $h );
	}
}, 100 );
add_filter( 'wc_order_attribution_allow_tracking', '__return_false' );
add_filter( 'pre_option_woocommerce_feature_order_attribution_enabled', fn() => 'no' );
add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'rb-fonts', RB_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );
// Home page title and description for search and link previews.
const RB_TITLE = 'RealBeef Africa | 100% Grass-Fed Beef Tallow, delivered in Nairobi & countrywide';
const RB_DESC  = 'Pure, single-ingredient grass-fed beef tallow for high-heat cooking. 500g, 1kg and 2kg jars, value packs and bulk supply. Same-day Nairobi delivery, countrywide courier, order on WhatsApp 0703 973 787.';
add_filter( 'pre_get_document_title', fn( $t ) => is_front_page() ? RB_TITLE : $t );
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) return;
	$img = rb_photo( 'realbeef-1kg.webp' );
	printf(
		'<meta name="description" content="%1$s"><meta property="og:type" content="website"><meta property="og:locale" content="en_KE"><meta property="og:title" content="%2$s"><meta property="og:description" content="%3$s"><meta property="og:image" content="%4$s">' . "\n",
		esc_attr( RB_DESC ),
		esc_attr( "RealBeef Africa: Mother Nature's Powerhouse" ),
		esc_attr( '100% grass-fed beef tallow. Zero additives. Same-day Nairobi delivery.' ),
		esc_url( $img )
	);
}, 2 );
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('rb-js')</script>\n";
	echo '<link rel="icon" href="' . esc_url( rb_asset( 'icon.png' ) ) . '" type="image/png">' . "\n";
	echo '<meta name="theme-color" content="#1A1814">' . "\n";
}, 1 );

add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );
add_filter( 'pre_option_woocommerce_coming_soon', fn() => 'no' );
add_filter( 'woocommerce_coming_soon_exclude', '__return_true' );

// No WooCommerce checkout: orders go to WhatsApp from the theme's cart.
add_filter( 'woocommerce_is_purchasable', '__return_false' );
// The shop page, a category or a product page open the one-page shop instead.
add_action( 'template_redirect', function () {
	if ( is_shop() || is_product_category() ) {
		$cat = is_product_category() ? '?cat=' . get_queried_object()->slug : '';
		wp_safe_redirect( home_url( '/' . $cat . '#shop' ), 301 );
		exit;
	}
	if ( is_product() ) {
		wp_safe_redirect( home_url( '/#p-' . get_post_field( 'post_name', get_queried_object_id() ) ), 301 );
		exit;
	}
} );

/* Shop ----------------------------------------------------------------------------------------------------------- */

function rb_card( $p, $base ) {
	$jars = '';
	$n    = $p['stack'];
	for ( $i = 0; $i < $n; $i++ ) {
		$off   = $i - ( $n - 1 ) / 2;
		$main  = $off == 0 || ( $n === 2 && $i === 1 );
		$jars .= sprintf(
			'<img src="%1$s" alt="%2$s" width="560" height="960" loading="lazy" style="--off:%3$s;--scale:%4$s;z-index:%5$d">',
			esc_url( $p['img'] ),
			$main ? esc_attr( $p['name'] . ' ' . $p['size'] ) : '',
			$off,
			1 - abs( $off ) * 0.12,
			10 - abs( $off )
		);
	}
	$tags = '';
	if ( $p['badge'] ) $tags .= '<span class="rb-tag">' . esc_html( $p['badge'] ) . '</span>';
	if ( $p['price'] && $p['was'] ) $tags .= '<span class="rb-tag rb-tag--sage">Save ' . rb_ksh( $p['was'] - $p['price'] ) . '</span>';
	$sample = RB_PREVIEW && $p['sample'] ? '<span class="rb-card__sample">Sample</span>' : '';

	if ( $p['price'] ) {
		$rate  = $p['grams'] ? round( $p['price'] / $p['grams'] * 100 ) : 0;
		$less  = $rate && $base ? round( ( 1 - $rate / $base ) * 100 ) : 0;
		$buy   = sprintf(
			'<p class="rb-card__price">%1$s%2$s</p><p class="rb-card__rate">%3$s per 100g%4$s</p>'
			. '<div class="rb-card__buy"><div class="rb-qty"><button type="button" data-rb-step="-1" aria-label="Fewer">−</button><span data-rb-qty>1</span><button type="button" data-rb-step="1" aria-label="More">+</button></div>'
			. '<button type="button" class="rb-btn-solid" data-rb-add>%5$s</button></div>'
			. '<a class="rb-link-arrow rb-link-arrow--wa" data-rb-instant href="%6$s" target="_blank" rel="noopener">WhatsApp instant order <span aria-hidden="true">→</span></a>',
			rb_ksh( $p['price'] ),
			$p['was'] ? ' <s>' . rb_ksh( $p['was'] ) . '</s>' : '',
			rb_ksh( $rate ),
			$less > 0 ? " · $less% less than the 500g" : '',
			$n > 1 ? 'Add bundle' : 'Add to cart',
			esc_url( rb_wa( "Hi RealBeef! I'd like 1 × {$p['name']} ({$p['size']}) — " . rb_ksh( $p['price'] ) . '. My drop-off location: ' ) )
		);
	} else {
		$balm = $p['cat'] === 'skincare';
		$buy  = sprintf(
			'<p class="rb-card__price">%1$s</p><p class="rb-card__rate rb-muted">%2$s</p><a class="rb-btn-wa rb-btn-block" href="%3$s" target="_blank" rel="noopener">%4$s</a>',
			$balm ? 'Join the waitlist' : 'Price on WhatsApp',
			$balm ? "We'll message you when it lands." : 'Tiered pricing for shops, butcheries and kitchens.',
			esc_url( rb_wa( $p['enquire'] ) ),
			$balm ? 'Notify me' : 'Get bulk pricing'
		);
	}

	return sprintf(
		'<li class="rb-card" id="p-%1$s" data-rb-product="%1$s" data-cat="%2$s" data-uses="%3$s" data-search="%4$s"><div class="rb-card__img">%5$s<div class="rb-card__tags">%6$s</div>%7$s</div><div class="rb-card__txt"><p class="rb-card__size">%8$s</p><h3>%9$s</h3><p class="rb-card__blurb">%10$s</p><div class="rb-card__foot">%11$s</div></div></li>',
		esc_attr( $p['id'] ),
		esc_attr( $p['cat'] ),
		esc_attr( implode( ' ', $p['uses'] ) ),
		esc_attr( strtolower( "{$p['name']} {$p['size']} {$p['blurb']} {$p['cat']} " . implode( ' ', $p['uses'] ) ) ),
		$jars,
		$tags,
		$sample,
		esc_html( $p['size'] ),
		esc_html( $p['name'] ),
		esc_html( $p['blurb'] ),
		$buy
	);
}

function rb_zone_switch() {
	$out = '';
	foreach ( RB_ZONES as $key => $z ) {
		$out .= sprintf( '<button type="button" role="radio" data-rb-zone="%1$s" aria-checked="%2$s">%3$s</button>', esc_attr( $key ), $key === 'nairobi' ? 'true' : 'false', esc_html( $z['short'] ) );
	}
	return '<div class="rb-zone" role="radiogroup" aria-label="Delivery zone">' . $out . '</div>';
}

add_shortcode( 'rb_shop', function () {
	$products = rb_products();
	$base     = 0;
	foreach ( $products as $p ) {
		if ( $p['grams'] === 500 && $p['price'] && $p['stack'] === 1 ) $base = round( $p['price'] / 5 );
	}
	$tabs  = '<button type="button" class="is-on" data-rb-cat="all" aria-pressed="true">All tallow</button>';
	$order = $names = [];
	foreach ( get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ get_option( 'default_product_cat' ) ] ] ) as $t ) {
		$order[ $t->slug ] = (int) get_term_meta( $t->term_id, 'order', true );
		$names[ $t->slug ] = $t->name;
	}
	asort( $order );
	foreach ( array_keys( $order ) as $slug ) {
		$tabs .= sprintf( '<button type="button" data-rb-cat="%1$s" aria-pressed="false">%2$s</button>', esc_attr( $slug ), esc_html( $names[ $slug ] ) );
	}
	$uses = '';
	foreach ( RB_USES as $key => [ $label, $hint ] ) {
		$uses .= sprintf( '<button type="button" data-rb-use="%1$s" aria-pressed="false" title="%2$s">%3$s</button>', esc_attr( $key ), esc_attr( $hint ), esc_html( $label ) );
	}
	$diet = '';
	foreach ( RB_DIET as $i => $d ) $diet .= ( $i ? '<i aria-hidden="true">|</i>' : '' ) . '<span>' . esc_html( $d ) . '</span>';
	$cards = '';
	foreach ( $products as $p ) $cards .= rb_card( $p, $base );
	$nb = RB_ZONES['nairobi'];

	return '<div data-rb-shop>'
		. '<div class="rb-tabs" role="group" aria-label="Shop categories">' . $tabs . '</div>'
		. '<div class="rb-filters"><div class="rb-uses"><span class="rb-field-label">Cooking for</span>' . $uses . '</div>'
		. '<div class="rb-filters__zone">' . rb_zone_switch() . '<p data-rb-zone-note>' . esc_html( $nb['eta'] ) . ' · ' . rb_ksh( $nb['fee'] ) . '</p></div></div>'
		. '<div class="rb-shop-notes"><p class="rb-diet"><b>Every jar is</b>' . $diet . '</p><p class="rb-cutoff-line" data-rb-cutoff-zone><span data-rb-cutoff>Same-day Nairobi dispatch closes at ' . rb_cutoff_label() . '</span></p></div>'
		. '<p class="rb-results" data-rb-results hidden></p>'
		. '<ul class="rb-cards">' . $cards . '</ul>'
		. '<div class="rb-empty" data-rb-empty hidden><p>Nothing matches that yet</p><button type="button" class="rb-btn-solid" data-rb-reset>Show all tallow</button></div>'
		. '</div>';
} );

add_shortcode( 'rb_stockists', function () {
	$out = '';
	foreach ( RB_STOCKISTS as [ $name, $where, $href ] ) {
		$n    = $href ? '<a href="' . esc_url( $href ) . '" target="_blank" rel="noopener">' . esc_html( $name ) . '</a>' : '<span>' . esc_html( $name ) . '</span>';
		$out .= '<li>' . $n . '<small>' . esc_html( $where ) . '</small></li>';
	}
	return '<ul class="rb-stockists">' . $out . '</ul>';
} );

add_shortcode( 'rb_reviews', function () {
	$out = '';
	foreach ( RB_REVIEWS as [ $quote, $name, $role ] ) {
		$out .= sprintf( '<li><p class="rb-stars" aria-label="5 out of 5">★★★★★</p><blockquote>&ldquo;%1$s&rdquo;</blockquote><p class="rb-reviews__name">%2$s</p><p class="rb-reviews__role">%3$s</p></li>', esc_html( $quote ), esc_html( $name ), esc_html( $role ) );
	}
	$note = RB_PREVIEW ? '<p class="rb-small rb-center rb-gold">Sample reviews, to be replaced with real customer messages.</p>' : '';
	return '<dl class="rb-stats rb-stats--center"><div><dt>' . RB_FOLLOWERS . '</dt><dd>Followers</dd></div><div><dt>1,000+</dt><dd>Cooking posts</dd></div><div><dt>100%</dt><dd>Recommend</dd></div></dl>'
		. '<ul class="rb-reviews rb-reveal">' . $out . '</ul>' . $note;
} );

add_shortcode( 'rb_faq', function () {
	$out = '';
	foreach ( rb_faq() as $i => [ $q, $a ] ) {
		$out .= sprintf( '<details%1$s><summary>%2$s</summary><p>%3$s</p></details>', $i ? '' : ' open', esc_html( $q ), esc_html( $a ) );
	}
	return '<div class="rb-faq">' . $out . '</div>';
} );

add_shortcode( 'rb_cutoff', fn() => '<span data-rb-cutoff>Same-day Nairobi dispatch closes at ' . rb_cutoff_label() . '</span>' );
add_shortcode( 'rb_followers', fn() => RB_FOLLOWERS );
add_shortcode( 'rb_cutoff_time', fn() => rb_cutoff_label() );

add_shortcode( 'rb_footer', function () {
	$pay = '';
	foreach ( [ 'M-Pesa Buy Goods / Paybill', 'Airtel Money', 'Visa / Mastercard', 'Pay on delivery (Nairobi)' ] as $p ) $pay .= '<li>' . esc_html( $p ) . '</li>';
	return '<div class="rb-foot"><div class="rb-foot__brand">' . rb_logo() . '<p>Mother Nature&rsquo;s Powerhouse. Pure, single-ingredient grass-fed beef tallow for high-heat cooking. Made in Africa.</p>'
		. '<div class="rb-social"><a href="' . esc_url( RB_IG ) . '" target="_blank" rel="noopener">Instagram</a><a href="' . esc_url( RB_FB ) . '" target="_blank" rel="noopener">Facebook</a><a href="' . esc_url( rb_wa( 'Hi RealBeef!' ) ) . '" target="_blank" rel="noopener">WhatsApp</a></div></div>'
		. '<nav aria-label="Shop"><h3>Shop</h3><a href="/?cat=starter#shop" data-rb-goto-cat="starter">Starter jars</a><a href="/?cat=family#shop" data-rb-goto-cat="family">Family kitchen jars</a><a href="/?cat=value#shop" data-rb-goto-cat="value">Value packs</a><a href="/?cat=chef#shop" data-rb-goto-cat="chef">Chef &amp; bulk</a><a href="/#faq">FAQ</a></nav>'
		. '<div><h3>Contact us</h3><p><a href="tel:' . RB_TEL . '">Call ' . RB_PHONE_INTL . '</a></p><p><a href="' . esc_url( rb_wa( 'Hi RealBeef!' ) ) . '" target="_blank" rel="noopener">WhatsApp ' . RB_PHONE . '</a></p><p>' . RB_IG_HANDLE . '</p><p class="rb-dim">Nairobi, Kenya · delivering countrywide</p></div>'
		. '<div><h3>We accept</h3><ul class="rb-pay">' . $pay . '</ul></div></div>'
		. '<p class="rb-copy">© ' . gmdate( 'Y' ) . ' RealBeef Africa. All rights reserved.' . ( RB_PREVIEW ? '<span>Preview build: bundle prices, delivery fees, cutoff, stock photos and reviews are samples.</span>' : '' ) . '</p>'
		. '<p class="rb-credit">Developed by <a href="mailto:salvatorewanjohi@gmail.com">Wahome</a></p>';
} );

/* Cart drawer, calculator, toasts and the phone bar: one copy per page, driven by rb.js -------------------------- */
add_action( 'wp_footer', function () {
	$pay = '';
	foreach ( [ 'mpesa' => 'M-Pesa', 'delivery' => 'Pay on delivery (Nairobi)', 'card' => 'Card / Airtel Money' ] as $k => $label ) {
		$pay .= sprintf( '<button type="button" data-rb-pay="%1$s" aria-pressed="%2$s">%3$s</button>', $k, $k === 'mpesa' ? 'true' : 'false', esc_html( $label ) );
	}
	?>
<div class="rb-drawer" data-rb-drawer hidden>
	<button type="button" class="rb-drawer__shade" data-rb-close aria-label="Close cart"></button>
	<aside class="rb-drawer__panel" role="dialog" aria-modal="true" aria-label="Your cart">
		<header class="rb-drawer__head"><h2>Your cart <small data-rb-count></small></h2><button type="button" class="rb-x" data-rb-close aria-label="Close cart">×</button></header>
		<div class="rb-drawer__empty" data-rb-cart-empty>
			<img src="<?php echo esc_url( rb_photo( 'realbeef-1kg.webp' ) ); ?>" alt="" width="96" height="160">
			<p class="rb-drawer__empty-title">Your cart is empty</p>
			<p>Most kitchens start with the 1kg Family Kitchen Jar.</p>
			<button type="button" class="rb-btn-solid" data-rb-add-id="family-kitchen-jar">Add the 1kg jar</button>
		</div>
		<div class="rb-drawer__full" data-rb-cart-full hidden>
			<div class="rb-free"><p data-rb-free-text></p><span><i data-rb-free-bar></i></span></div>
			<div class="rb-drawer__body">
				<ul class="rb-lines" data-rb-lines></ul>
				<p class="rb-field-label">Delivery</p>
				<?php echo rb_zone_switch(); ?>
				<p class="rb-small" data-rb-zone-eta></p>
				<p class="rb-small" data-rb-cutoff-zone><span data-rb-cutoff></span></p>
				<label class="rb-field"><span class="rb-field-label">Your name</span><input data-rb-name autocomplete="name" placeholder="e.g. Wanjiru"></label>
				<label class="rb-field"><span class="rb-field-label">Drop-off location <b>*</b></span><input data-rb-location autocomplete="street-address" placeholder="Estate, building, landmark"></label>
				<p class="rb-field-label">Pay with</p>
				<div class="rb-pay-pick"><?php echo $pay; ?></div>
				<label class="rb-refill"><input type="checkbox" data-rb-refill><span><b>Monthly refill reminder</b>A WhatsApp nudge before you run out. You confirm every order.</span></label>
			</div>
			<footer class="rb-drawer__foot">
				<dl><div><dt>Subtotal</dt><dd data-rb-subtotal></dd></div><div><dt data-rb-zone-label></dt><dd data-rb-delivery></dd></div><div class="rb-total"><dt>Total</dt><dd data-rb-total></dd></div></dl>
				<button type="button" class="rb-btn-wa rb-btn-block" data-rb-send disabled>Order via WhatsApp</button>
				<p class="rb-small rb-center" data-rb-send-hint>Add your drop-off location to send the order.</p>
			</footer>
		</div>
	</aside>
</div>

<div class="rb-modal" data-rb-calc hidden>
	<button type="button" class="rb-drawer__shade" data-rb-calc-close aria-label="Close calculator"></button>
	<div class="rb-modal__panel" role="dialog" aria-modal="true" aria-labelledby="rb-calc-title">
		<button type="button" class="rb-x" data-rb-calc-close aria-label="Close">×</button>
		<p class="rb-label">Usage calculator</p>
		<h2 id="rb-calc-title">How much tallow does your kitchen need?</h2>
		<p class="rb-field-label">Who&rsquo;s eating</p>
		<div class="rb-chips rb-chips--4" data-rb-calc-group="people">
			<button type="button" data-v="1"><b>Just me</b><span>Single cook</span></button>
			<button type="button" data-v="2"><b>Two of us</b><span>Couple / flatmates</span></button>
			<button type="button" data-v="4" class="is-on"><b>Family</b><span>3 to 5 people</span></button>
			<button type="button" data-v="7"><b>Big house</b><span>6+ or meal-prepper</span></button>
		</div>
		<p class="rb-field-label">How often you cook with fat</p>
		<div class="rb-chips rb-chips--3" data-rb-calc-group="freq">
			<button type="button" data-v="light"><b>A few times a week</b></button>
			<button type="button" data-v="daily" class="is-on"><b>Every day</b></button>
			<button type="button" data-v="heavy"><b>Daily + deep frying</b></button>
		</div>
		<div class="rb-calc__row">
			<div><p class="rb-field-label">Stock up for</p><div class="rb-chips" data-rb-calc-group="months"><button type="button" data-v="1" class="is-on"><b>1 month</b></button><button type="button" data-v="2"><b>2 months</b></button><button type="button" data-v="3"><b>3 months</b></button></div></div>
			<div><p class="rb-field-label">Purchase</p><div class="rb-chips" data-rb-calc-group="refill"><button type="button" data-v="0"><b>One-time</b></button><button type="button" data-v="1" class="is-on"><b>Monthly refill</b></button></div></div>
		</div>
		<div class="rb-calc__result rb-leaves" data-rb-calc-result></div>
		<div class="rb-calc__ctas"><button type="button" class="rb-btn-gold" data-rb-calc-add>Add bundle to cart</button><a class="rb-btn-wa" data-rb-calc-wa href="#" target="_blank" rel="noopener">Instant WhatsApp checkout</a></div>
		<p class="rb-small rb-center">Estimates assume about a tablespoon per pan. Deep frying uses more.</p>
	</div>
</div>

<div class="rb-toasts" data-rb-toasts aria-live="polite"></div>

<nav class="rb-mobile-bar" aria-label="Quick actions"><button type="button" data-rb-open-cart>View cart <span data-rb-bar-total></span></button><a href="<?php echo esc_url( rb_wa( "Hi RealBeef! I'd like to order beef tallow." ) ); ?>" target="_blank" rel="noopener" aria-label="Order on WhatsApp">WhatsApp</a></nav>
	<?php
	// Structured data: a store with its products and prices.
	$offers = [];
	foreach ( rb_products() as $p ) {
		if ( ! $p['price'] ) continue;
		$offers[] = [ '@type' => 'Product', 'name' => "RealBeef {$p['name']} {$p['size']}", 'description' => $p['blurb'], 'image' => $p['img'], 'offers' => [ '@type' => 'Offer', 'price' => $p['price'], 'priceCurrency' => 'KES', 'availability' => 'https://schema.org/InStock' ] ];
	}
	echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@graph' => array_merge( [ [ '@type' => 'Store', 'name' => 'RealBeef Africa', 'telephone' => RB_TEL, 'address' => [ '@type' => 'PostalAddress', 'addressLocality' => 'Nairobi', 'addressCountry' => 'KE' ], 'url' => home_url( '/' ) ] ], $offers ) ] ) . '</script>';
} );

/* Product editor: the shop-card fields, under Product data → General ---------------------------------------------- */
add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group"><p class="form-field"><strong>RealBeef shop card</strong></p>';
	woocommerce_wp_text_input( [ 'id' => '_rb_size', 'label' => 'Size label', 'description' => 'Shown above the name, e.g. 1kg or 2 × 1kg.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_rb_grams', 'label' => 'Total grams', 'type' => 'number', 'description' => 'Used for the price per 100g and the usage calculator. 0 = leave out of the calculator.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_rb_was', 'label' => 'Price as single jars (KSh)', 'type' => 'number', 'description' => 'For packs: what the same jars cost bought one by one. Shows a struck-out price and "Save KSh …".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_rb_stack', 'label' => 'Jars in the photo', 'type' => 'number', 'description' => 'How many copies of the jar photo to stack on the card (1–3).', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_rb_badge', 'label' => 'Badge', 'description' => 'Short tag on the photo, e.g. Best value jar. Leave empty for none.', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_rb_uses', 'label' => 'Cooking uses', 'description' => 'Comma-separated: searing, frying, roasting, mealprep, skin.', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_rb_sample', 'label' => 'Sample product', 'description' => 'Shows a "Sample" tag while the site is in preview.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_rb_enquire', 'label' => 'WhatsApp enquiry', 'description' => 'For products without a price: the message the button sends.', 'desc_tip' => true ] );
	echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_rb_size', '_rb_grams', '_rb_was', '_rb_stack', '_rb_badge', '_rb_uses' ] as $key ) {
		if ( isset( $_POST[ $key ] ) ) $product->update_meta_data( $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
	}
	if ( isset( $_POST['_rb_enquire'] ) ) $product->update_meta_data( '_rb_enquire', sanitize_textarea_field( wp_unslash( $_POST['_rb_enquire'] ) ) );
	$product->update_meta_data( '_rb_sample', isset( $_POST['_rb_sample'] ) ? 'yes' : 'no' );
} );

// Pitch build: out of search results until RealBeef signs off on prices, photos and copy.
if ( RB_PREVIEW ) add_filter( 'wp_robots', fn( $r ) => array_merge( $r, [ 'noindex' => true, 'nofollow' => true ] ) );

// WooCommerce hooks a mini-cart and an account link into the header navigation; the theme has its own cart.
add_filter( 'hooked_block_types', fn( $types ) => array_values( array_diff( $types, [ 'woocommerce/mini-cart', 'woocommerce/customer-account' ] ) ), 20 );

// The shortcode block runs wpautop, which wraps runs of links in <p>. All shortcode blocks here are ours and return
// finished markup, so skip it.
add_filter( 'pre_render_block', function ( $pre, $block ) {
	if ( ( $block['blockName'] ?? '' ) === 'core/shortcode' ) {
		return do_shortcode( trim( $block['innerHTML'] ) );
	}
	return $pre;
}, 10, 2 );
