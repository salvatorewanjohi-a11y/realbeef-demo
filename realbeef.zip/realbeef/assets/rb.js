/*
 * RealBeef Africa: the shop runs in the browser so the static copy works too. Products and settings come from
 * WooCommerce via window.RB (functions.php). Cart, delivery zone and details are kept in localStorage; checkout sends
 * an itemised order to RealBeef on WhatsApp.
 */
( () => {
	const RB = window.RB || { products: [], zones: {}, freeFrom: 0, cutoff: 14, wa: '' };
	const $ = ( s, r = document ) => r.querySelector( s );
	const $$ = ( s, r = document ) => Array.from( r.querySelectorAll( s ) );
	const calm = matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	const ksh = ( n ) => 'KSh ' + Number( n ).toLocaleString( 'en-KE' );
	const wa = ( text ) => `https://wa.me/${ RB.wa }?text=${ encodeURIComponent( text ) }`;
	const byId = ( id ) => RB.products.find( ( p ) => p.id === id );
	const PAY = { mpesa: 'M-Pesa', delivery: 'Pay on delivery (Nairobi)', card: 'Card / Airtel Money' };

	/* State ------------------------------------------------------------------------------------------------- */
	const KEY = 'realbeef-cart-v1';
	let state = { lines: [], zone: 'nairobi', name: '', location: '', payment: 'mpesa', refill: false };
	try {
		const saved = JSON.parse( localStorage.getItem( KEY ) || 'null' );
		if ( saved ) state = { ...state, ...saved, lines: ( saved.lines || [] ).filter( ( l ) => byId( l.id )?.price ) };
		if ( ! RB.zones[ state.zone ] ) state.zone = 'nairobi';
	} catch {}
	const save = () => {
		try {
			localStorage.setItem( KEY, JSON.stringify( state ) );
		} catch {}
	};

	const totals = () => {
		const lines = state.lines.map( ( l ) => ( { ...l, p: byId( l.id ) } ) ).filter( ( l ) => l.p && l.p.price );
		const subtotal = lines.reduce( ( s, l ) => s + l.p.price * l.qty, 0 );
		const count = lines.reduce( ( s, l ) => s + l.qty, 0 );
		const delivery = subtotal === 0 || subtotal >= RB.freeFrom ? 0 : RB.zones[ state.zone ].fee;
		return { lines, subtotal, count, delivery, total: subtotal + delivery };
	};
	const payment = () => ( state.payment === 'delivery' && state.zone !== 'nairobi' ? 'mpesa' : state.payment );

	/* Toasts ------------------------------------------------------------------------------------------------ */
	const toastBox = $( '[data-rb-toasts]' );
	const toast = ( title, body = '' ) => {
		if ( ! toastBox ) return;
		const el = document.createElement( 'div' );
		el.className = 'rb-toast';
		el.innerHTML = '<b></b><span></span>';
		el.firstChild.textContent = title;
		el.lastChild.textContent = body;
		toastBox.append( el );
		while ( toastBox.children.length > 3 ) toastBox.firstChild.remove();
		setTimeout( () => el.classList.add( 'is-out' ), 3000 );
		setTimeout( () => el.remove(), 3400 );
	};

	/* Cart ---------------------------------------------------------------------------------------------------- */
	const add = ( id, qty = 1, silent = false ) => {
		const p = byId( id );
		if ( ! p || ! p.price ) return;
		const line = state.lines.find( ( l ) => l.id === id );
		if ( line ) line.qty += qty;
		else state.lines.push( { id, qty } );
		save();
		render();
		const badge = $( '[data-rb-badge]' );
		if ( badge ) {
			badge.classList.remove( 'is-bump' );
			void badge.offsetWidth;
			badge.classList.add( 'is-bump' );
		}
		if ( ! silent ) toast( `${ p.name } ${ p.size } added`, 'Tap the cart to check out' );
	};
	const setQty = ( id, qty ) => {
		state.lines = qty <= 0 ? state.lines.filter( ( l ) => l.id !== id ) : state.lines.map( ( l ) => ( l.id === id ? { ...l, qty } : l ) );
		save();
		render();
	};

	const orderText = () => {
		const t = totals();
		const rows = t.lines.map( ( l ) => `• ${ l.qty } × ${ l.p.name } (${ l.p.size }) — ${ ksh( l.p.price * l.qty ) }` );
		return [
			"Hi RealBeef! I'd like to order:",
			'',
			...rows,
			'',
			`Subtotal: ${ ksh( t.subtotal ) }`,
			`Delivery: ${ RB.zones[ state.zone ].label } — ${ t.delivery === 0 ? 'FREE' : ksh( t.delivery ) }`,
			`*Total: ${ ksh( t.total ) }*`,
			'',
			`Name: ${ state.name || '—' }`,
			`Drop-off location: ${ state.location || '—' }`,
			`Payment: ${ PAY[ payment() ] }`,
			...( state.refill ? [ 'Please send me a monthly refill reminder on WhatsApp.' ] : [] ),
		].join( '\n' );
	};

	const drawer = $( '[data-rb-drawer]' );
	const render = () => {
		const t = totals();
		const badge = $( '[data-rb-badge]' );
		if ( badge ) {
			badge.hidden = t.count === 0;
			badge.textContent = t.count;
		}
		$$( '[data-rb-open-cart]' ).forEach( ( b ) => b.setAttribute( 'aria-label', `Open cart, ${ t.count } items` ) );
		const bar = $( '[data-rb-bar-total]' );
		if ( bar ) bar.textContent = t.count ? `(${ t.count }) · ${ ksh( t.total ) }` : '';

		// Zone switches and notes everywhere on the page.
		$$( '[data-rb-zone]' ).forEach( ( b ) => b.setAttribute( 'aria-checked', b.dataset.rbZone === state.zone ? 'true' : 'false' ) );
		const z = RB.zones[ state.zone ];
		$$( '[data-rb-zone-note]' ).forEach( ( el ) => ( el.textContent = `${ z.eta } · ${ ksh( z.fee ) }` ) );
		$$( '[data-rb-cutoff-zone]' ).forEach( ( el ) => ( el.hidden = state.zone !== 'nairobi' ) );
		if ( ! drawer ) return;

		$( '[data-rb-count]', drawer ).textContent = t.count ? `(${ t.count })` : '';
		$( '[data-rb-cart-empty]', drawer ).hidden = t.count > 0;
		$( '[data-rb-cart-full]', drawer ).hidden = t.count === 0;
		const left = Math.max( 0, RB.freeFrom - t.subtotal );
		$( '[data-rb-free-text]', drawer ).innerHTML = left > 0 ? `Add <b>${ ksh( left ) }</b> more for <b class="rb-free-ok">free delivery</b>` : '<b class="rb-free-ok">You&rsquo;ve unlocked free delivery</b>';
		$( '[data-rb-free-bar]', drawer ).style.width = `${ Math.min( 100, ( t.subtotal / RB.freeFrom ) * 100 ) }%`;
		$( '[data-rb-lines]', drawer ).innerHTML = t.lines
			.map(
				( l ) => `<li data-id="${ l.p.id }"><img src="${ l.p.img }" alt="" width="60" height="72"><div><strong>${ esc( l.p.name ) }</strong><small>${ esc( l.p.size ) }</small><div class="rb-qty"><button type="button" data-rb-line-step="-1" aria-label="Fewer">−</button><span>${ l.qty }</span><button type="button" data-rb-line-step="1" aria-label="More">+</button></div></div><div class="rb-lines__end">${ ksh( l.p.price * l.qty ) }<button type="button" data-rb-remove>Remove</button></div></li>`
			)
			.join( '' );
		$( '[data-rb-zone-eta]', drawer ).textContent = z.eta;
		$( '[data-rb-zone-label]', drawer ).textContent = z.label;
		$( '[data-rb-subtotal]', drawer ).textContent = ksh( t.subtotal );
		$( '[data-rb-delivery]', drawer ).innerHTML = t.delivery === 0 ? '<span class="rb-free-ok">FREE</span>' : ksh( t.delivery );
		$( '[data-rb-total]', drawer ).textContent = ksh( t.total );
		$$( '[data-rb-pay]', drawer ).forEach( ( b ) => {
			b.hidden = b.dataset.rbPay === 'delivery' && state.zone !== 'nairobi';
			b.setAttribute( 'aria-pressed', b.dataset.rbPay === payment() ? 'true' : 'false' );
		} );
		const ready = state.location.trim().length > 2;
		const send = $( '[data-rb-send]', drawer );
		send.disabled = ! ready;
		send.textContent = `Order via WhatsApp · ${ ksh( t.total ) }`;
		$( '[data-rb-send-hint]', drawer ).hidden = ready;
	};
	const esc = ( s ) => String( s ).replace( /[&<>"]/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } )[ c ] );

	// Opening and closing the drawer and the calculator.
	let lastFocus = null;
	const open = ( el ) => {
		if ( ! el ) return;
		lastFocus = document.activeElement;
		el.hidden = false;
		document.body.classList.add( 'rb-locked' );
		setTimeout( () => ( $( '.rb-x', el ) || el ).focus(), 50 );
	};
	const close = ( el ) => {
		if ( ! el || el.hidden ) return;
		el.hidden = true;
		if ( ! $( '[data-rb-drawer]:not([hidden]), [data-rb-calc]:not([hidden])' ) ) document.body.classList.remove( 'rb-locked' );
		if ( lastFocus ) lastFocus.focus();
	};

	if ( drawer ) {
		const name = $( '[data-rb-name]', drawer );
		const loc = $( '[data-rb-location]', drawer );
		const refill = $( '[data-rb-refill]', drawer );
		name.value = state.name;
		loc.value = state.location;
		refill.checked = state.refill;
		name.addEventListener( 'input', () => {
			state.name = name.value;
			save();
		} );
		loc.addEventListener( 'input', () => {
			state.location = loc.value;
			save();
			render();
		} );
		refill.addEventListener( 'change', () => {
			state.refill = refill.checked;
			save();
		} );
		drawer.addEventListener( 'click', ( e ) => {
			const li = e.target.closest( '[data-id]' );
			const step = e.target.closest( '[data-rb-line-step]' );
			if ( li && step ) {
				const line = state.lines.find( ( l ) => l.id === li.dataset.id );
				if ( line ) setQty( line.id, line.qty + Number( step.dataset.rbLineStep ) );
			}
			if ( li && e.target.closest( '[data-rb-remove]' ) ) setQty( li.dataset.id, 0 );
			const pay = e.target.closest( '[data-rb-pay]' );
			if ( pay ) {
				state.payment = pay.dataset.rbPay;
				save();
				render();
			}
			if ( e.target.closest( '[data-rb-send]' ) ) {
				window.open( wa( orderText() ), '_blank', 'noopener' );
				toast( 'Order sent to WhatsApp', "Hit send in WhatsApp and we'll confirm your rider or courier." );
			}
		} );
	}

	/* Page-wide clicks ------------------------------------------------------------------------------------------ */
	document.addEventListener( 'click', ( e ) => {
		const t = e.target;
		if ( t.closest( '[data-rb-open-cart]' ) ) open( drawer );
		if ( t.closest( '[data-rb-close]' ) ) close( drawer );
		if ( t.closest( '[data-rb-calc-open]' ) ) {
			calcRender();
			open( $( '[data-rb-calc]' ) );
		}
		if ( t.closest( '[data-rb-calc-close]' ) ) close( $( '[data-rb-calc]' ) );
		const zone = t.closest( '[data-rb-zone]' );
		if ( zone ) {
			state.zone = zone.dataset.rbZone;
			save();
			render();
		}
		const addId = t.closest( '[data-rb-add-id]' );
		if ( addId ) add( addId.dataset.rbAddId );
		// Shop links from the header, footer and use cards: filter in place instead of reloading the page.
		const cat = t.closest( '[data-rb-goto-cat]' );
		const use = t.closest( '[data-rb-goto-use]' );
		const link = t.closest( 'a[href]' );
		let catFromLink = null;
		if ( ! cat && link && shop ) {
			const u = new URL( link.href, location.href );
			if ( u.pathname === location.pathname && u.searchParams.get( 'cat' ) ) catFromLink = u.searchParams.get( 'cat' );
		}
		if ( ( cat || use || catFromLink ) && shop ) {
			e.preventDefault();
			if ( use ) filter( { use: use.dataset.rbGotoUse, cat: 'all' } );
			else filter( { cat: cat ? cat.dataset.rbGotoCat : catFromLink, use: null } );
			closeNav();
			shop.closest( 'section' ).scrollIntoView( { behavior: calm ? 'auto' : 'smooth' } );
		}
		// Phone menu: a link to a section on this page scrolls behind the open overlay, so close it first.
		if ( link && link.closest( '.wp-block-navigation__responsive-container.is-menu-open' ) && new URL( link.href ).pathname === location.pathname ) closeNav();
	} );
	addEventListener( 'keydown', ( e ) => {
		if ( e.key !== 'Escape' ) return;
		close( $( '[data-rb-calc]' ) );
		close( drawer );
	} );
	const closeNav = () => {
		const c = $( '.wp-block-navigation__responsive-container.is-menu-open .wp-block-navigation__responsive-container-close' );
		if ( c ) c.click();
	};

	/* Shop: tabs, uses, search ---------------------------------------------------------------------------------- */
	const shop = $( '[data-rb-shop]' );
	const view = { cat: 'all', use: null, q: '' };
	const filter = ( next = {} ) => {
		Object.assign( view, next );
		if ( ! shop ) return;
		$$( '[data-rb-cat]', shop ).forEach( ( b ) => {
			b.classList.toggle( 'is-on', b.dataset.rbCat === view.cat );
			b.setAttribute( 'aria-pressed', b.dataset.rbCat === view.cat ? 'true' : 'false' );
		} );
		$$( '[data-rb-use]', shop ).forEach( ( b ) => {
			b.classList.toggle( 'is-on', b.dataset.rbUse === view.use );
			b.setAttribute( 'aria-pressed', b.dataset.rbUse === view.use ? 'true' : 'false' );
		} );
		const q = view.q.trim().toLowerCase();
		let shown = 0;
		$$( '[data-rb-product]', shop ).forEach( ( li ) => {
			const hay = li.dataset.search;
			const ok =
				( view.cat === 'all' || li.dataset.cat === view.cat ) &&
				( ! view.use || li.dataset.uses.split( ' ' ).includes( view.use ) ) &&
				// "1 kg" and "1kg" should both find the 1kg jar.
				( ! q || q.split( /\s+/ ).every( ( w ) => hay.includes( w ) ) || hay.replace( /\s+/g, '' ).includes( q.replace( /\s+/g, '' ) ) );
			li.hidden = ! ok;
			if ( ok ) shown++;
		} );
		const res = $( '[data-rb-results]', shop );
		const filtered = view.cat !== 'all' || view.use || q;
		res.hidden = ! filtered;
		if ( filtered ) {
			res.innerHTML = `Showing ${ shown } ${ shown === 1 ? 'option' : 'options' }${ q ? ` for &ldquo;${ esc( view.q ) }&rdquo;` : '' }. <button type="button" data-rb-reset>Show everything</button>`;
		}
		$( '[data-rb-empty]', shop ).hidden = shown > 0;
	};
	if ( shop ) {
		shop.addEventListener( 'click', ( e ) => {
			const cat = e.target.closest( '[data-rb-cat]' );
			if ( cat ) filter( { cat: cat.dataset.rbCat } );
			const use = e.target.closest( '[data-rb-use]' );
			if ( use ) filter( { use: view.use === use.dataset.rbUse ? null : use.dataset.rbUse } );
			if ( e.target.closest( '[data-rb-reset]' ) ) {
				const s = $( '[data-rb-search]' );
				if ( s ) s.value = '';
				filter( { cat: 'all', use: null, q: '' } );
			}
			const card = e.target.closest( '[data-rb-product]' );
			if ( ! card ) return;
			const qtyEl = $( '[data-rb-qty]', card );
			const step = e.target.closest( '[data-rb-step]' );
			if ( step && qtyEl ) {
				const qty = Math.max( 1, Number( qtyEl.textContent ) + Number( step.dataset.rbStep ) );
				qtyEl.textContent = qty;
				const p = byId( card.dataset.rbProduct );
				const inst = $( '[data-rb-instant]', card );
				if ( p && inst ) inst.href = wa( `Hi RealBeef! I'd like ${ qty } × ${ p.name } (${ p.size }) — ${ ksh( p.price * qty ) }. My drop-off location: ` );
			}
			const addBtn = e.target.closest( '[data-rb-add]' );
			if ( addBtn && qtyEl ) {
				add( card.dataset.rbProduct, Number( qtyEl.textContent ) );
				const label = addBtn.textContent;
				addBtn.textContent = 'Added ✓';
				setTimeout( () => ( addBtn.textContent = label ), 1400 );
			}
		} );
		const params = new URLSearchParams( location.search );
		if ( params.get( 'cat' ) ) filter( { cat: params.get( 'cat' ) } );
		// A product link (/#p-slug) highlights that card.
		const hashCard = location.hash.startsWith( '#p-' ) && $( location.hash );
		if ( hashCard ) {
			hashCard.classList.add( 'is-flash' );
			setTimeout( () => hashCard.classList.remove( 'is-flash' ), 2400 );
		}
	}

	// Header search: filters the shop as you type.
	const searchBtn = $( '[data-rb-search-toggle]' );
	const searchPanel = $( '[data-rb-search-panel]' );
	const searchInput = $( '[data-rb-search]' );
	if ( searchBtn && searchPanel ) {
		searchBtn.addEventListener( 'click', () => {
			const show = searchPanel.hidden;
			searchPanel.hidden = ! show;
			searchBtn.setAttribute( 'aria-expanded', show ? 'true' : 'false' );
			document.body.classList.toggle( 'rb-searching', show );
			if ( show ) searchInput.focus();
		} );
		let jumped = false;
		searchInput.addEventListener( 'input', () => {
			if ( ! shop ) {
				return;
			}
			filter( { q: searchInput.value } );
			if ( searchInput.value && ! jumped ) {
				jumped = true;
				shop.closest( 'section' ).scrollIntoView( { behavior: calm ? 'auto' : 'smooth' } );
			}
			if ( ! searchInput.value ) jumped = false;
		} );
		searchPanel.addEventListener( 'submit', ( e ) => {
			e.preventDefault();
			if ( ! shop ) location.href = '/#shop';
			else shop.closest( 'section' ).scrollIntoView( { behavior: calm ? 'auto' : 'smooth' } );
		} );
	}

	/* Same-day cutoff countdown, in Nairobi time (UTC+3 all year) ----------------------------------------------- */
	const label = RB.cutoff > 12 ? `${ RB.cutoff - 12 } PM` : `${ RB.cutoff } AM`;
	const pad = ( n ) => String( n ).padStart( 2, '0' );
	const tick = () => {
		const now = new Date( Date.now() + 3 * 3600000 ); // read with getUTC* as Nairobi wall time
		const secs = now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds();
		const left = RB.cutoff * 3600 - secs;
		const html =
			left > 0
				? `Same-day Nairobi dispatch closes at ${ label }: <b>${ pad( Math.floor( left / 3600 ) ) }:${ pad( Math.floor( ( left % 3600 ) / 60 ) ) }:${ pad( left % 60 ) }</b> left`
				: 'Today&rsquo;s riders have left. Order now to be first out tomorrow';
		$$( '[data-rb-cutoff]' ).forEach( ( el ) => ( el.innerHTML = html ) );
	};
	tick();
	setInterval( tick, 1000 );

	/* Usage calculator -------------------------------------------------------------------------------------------- */
	const calc = $( '[data-rb-calc]' );
	const FREQ = { light: [ 5, 1 ], daily: [ 10, 1 ], heavy: [ 14, 1.35 ] };
	const pick = ( g ) => $( `[data-rb-calc-group="${ g }"] .is-on`, calc )?.dataset.v;
	// Cheapest mix of jars and packs covering the target (all sizes are multiples of 500g).
	const bestMix = ( target ) => {
		const items = RB.products.filter( ( p ) => p.price && p.grams > 0 && p.grams % 500 === 0 );
		const need = Math.max( 1, Math.ceil( target / 500 ) );
		const cap = need + 2;
		const cost = Array( cap + 1 ).fill( Infinity );
		const from = Array( cap + 1 ).fill( null );
		const n = Array( cap + 1 ).fill( 0 );
		cost[ 0 ] = 0;
		for ( let k = 1; k <= cap; k++ ) {
			for ( const p of items ) {
				const u = p.grams / 500;
				if ( u > k || cost[ k - u ] === Infinity ) continue;
				const c = cost[ k - u ] + p.price;
				if ( c < cost[ k ] || ( c === cost[ k ] && n[ k - u ] + 1 < n[ k ] ) ) {
					cost[ k ] = c;
					from[ k ] = p;
					n[ k ] = n[ k - u ] + 1;
				}
			}
		}
		let best = need;
		for ( let k = need; k <= cap; k++ ) if ( cost[ k ] < cost[ best ] ) best = k;
		const out = new Map();
		for ( let k = best; k > 0 && from[ k ]; k -= from[ k ].grams / 500 ) {
			const p = from[ k ];
			out.set( p.id, { p, qty: ( out.get( p.id )?.qty || 0 ) + 1 } );
		}
		return [ ...out.values() ].sort( ( a, b ) => b.p.grams - a.p.grams );
	};
	let mix = [];
	const calcRender = () => {
		if ( ! calc ) return;
		const people = Number( pick( 'people' ) );
		const [ sessions, factor ] = FREQ[ pick( 'freq' ) ];
		const months = Number( pick( 'months' ) );
		const refill = pick( 'refill' ) === '1';
		// About a tablespoon per pan for one, a little more for each extra mouth.
		const monthly = Math.round( ( ( 15 + 6 * ( people - 1 ) ) * sessions * factor * 52 ) / 12 / 50 ) * 50;
		mix = bestMix( monthly * months );
		const total = mix.reduce( ( s, m ) => s + m.p.price * m.qty, 0 );
		const grams = mix.reduce( ( s, m ) => s + m.p.grams * m.qty, 0 );
		const weeks = Math.max( 1, Math.round( ( grams / monthly ) * 4.3 ) );
		const kg = ( g ) => ( g >= 1000 ? `${ +( g / 1000 ).toFixed( 1 ) }kg` : `${ g }g` );
		$( '[data-rb-calc-result]', calc ).innerHTML =
			`<p>Your kitchen uses about <b>${ kg( monthly ) }</b> a month. We recommend:</p><ul>` +
			mix.map( ( m ) => `<li><span>${ m.qty } × ${ esc( m.p.name ) } (${ esc( m.p.size ) })</span><span>${ ksh( m.p.price * m.qty ) }</span></li>` ).join( '' ) +
			`</ul><div class="rb-calc__total"><span>${ kg( grams ) } · lasts about ${ weeks } weeks${ total >= RB.freeFrom ? ' · <b>free delivery</b>' : '' }</span><strong>${ ksh( total ) }</strong></div>` +
			( refill ? '<p class="rb-calc__note">We&rsquo;ll message you on WhatsApp each month before you run out. No auto-charge: you confirm every refill.</p>' : '' ) +
			( mix.some( ( m ) => m.p.sample ) ? '<p class="rb-calc__note">Includes sample bundle prices.</p>' : '' );
		const text = [
			'Hi RealBeef! The usage calculator recommended:',
			...mix.map( ( m ) => `• ${ m.qty } × ${ m.p.name } (${ m.p.size }) — ${ ksh( m.p.price * m.qty ) }` ),
			`Total: ${ ksh( total ) } (before delivery)`,
			`Delivery: ${ RB.zones[ state.zone ].label }`,
			...( refill ? [ 'Please remind me on WhatsApp every month to refill.' ] : [] ),
			'My drop-off location: ',
		].join( '\n' );
		$( '[data-rb-calc-wa]', calc ).href = wa( text );
	};
	if ( calc ) {
		calc.addEventListener( 'click', ( e ) => {
			const chip = e.target.closest( '[data-rb-calc-group] button' );
			if ( chip ) {
				$$( 'button', chip.parentElement ).forEach( ( b ) => {
					b.classList.toggle( 'is-on', b === chip );
					b.setAttribute( 'aria-pressed', b === chip ? 'true' : 'false' );
				} );
				calcRender();
			}
			if ( e.target.closest( '[data-rb-calc-add]' ) ) {
				mix.forEach( ( m ) => add( m.p.id, m.qty, true ) );
				state.refill = pick( 'refill' ) === '1';
				const r = $( '[data-rb-refill]' );
				if ( r ) r.checked = state.refill;
				save();
				toast( 'Bundle added to cart', mix.map( ( m ) => `${ m.qty } × ${ m.p.size }` ).join( ' + ' ) );
				close( calc );
			}
		} );
	}

	/* Club sign-up: sends the details on WhatsApp ----------------------------------------------------------------- */
	const club = $( '[data-rb-club]' );
	if ( club ) {
		club.addEventListener( 'submit', ( e ) => {
			e.preventDefault();
			const f = new FormData( club );
			window.open( wa( `Hi RealBeef! Please add me to the Clean-Cooking Club for seed-oil-free recipes and bundle discounts.\nName: ${ f.get( 'name' ) }\nPhone: ${ f.get( 'phone' ) }` ), '_blank', 'noopener' );
			toast( 'Almost in!', 'Hit send in WhatsApp to join the club.' );
		} );
	}

	/* Header over the cover on the home page, then solid once the page scrolls --------------------------------------- */
	if ( document.body.classList.contains( 'home' ) ) {
		const paint = () => document.body.classList.toggle( 'rb-scrolled', window.scrollY > 140 );
		paint();
		addEventListener( 'scroll', paint, { passive: true } );
	}

	render();
	filter();

	/* Sections rise in as they scroll into view ------------------------------------------------------------------------- */
	if ( calm || ! ( 'IntersectionObserver' in window ) ) {
		$$( '.rb-reveal' ).forEach( ( el ) => el.classList.add( 'is-in' ) );
		return;
	}
	$$( 'main .rb-title, .rb-intro__copy, .rb-intro__art, .rb-band > *, .rb-uses-grid > li' ).forEach( ( el ) => el.classList.add( 'rb-reveal' ) );
	const io = new IntersectionObserver(
		( entries ) =>
			entries.forEach( ( en ) => {
				if ( en.isIntersecting ) {
					en.target.classList.add( 'is-in' );
					io.unobserve( en.target );
				}
			} ),
		{ rootMargin: '0px 0px -8% 0px' }
	);
	$$( '.rb-reveal' ).forEach( ( el ) => io.observe( el ) );
} )();
